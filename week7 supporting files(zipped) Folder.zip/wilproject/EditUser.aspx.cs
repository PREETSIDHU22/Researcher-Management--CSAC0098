﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace wilproject
{
    public partial class EditUser : System.Web.UI.Page
    {
        public string conString = "Data Source=DESKTOP-R720FQ7\\SQLEXPRESS;Initial Catalog=wilprojectDB;Integrated Security=True";
        public string accesstype = "";
        protected void Page_Load(object sender, EventArgs e)
        {           
            SqlConnection connectForEdit = new SqlConnection(conString);
            connectForEdit.Open();
            string query = "Select * from signUp" +
               " where Email='" + Session["UserName"] + "'";
            SqlCommand cmd = new SqlCommand(query, connectForEdit);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                txtEmail.Text = sdr.GetString(0);
                txtPasswd.Attributes["value"] = sdr.GetString(1);
                txtFName.Text = sdr.GetString(3);
                txtLName.Text = sdr.GetString(4);
                txtDOB.Text = sdr.GetDateTime(5).ToString();
                accesstype = sdr.GetString(6);
            }
            else
            {
                // Record not found
            }
            connectForEdit.Close();


        }

        protected void Update_Click(object sender, EventArgs e)
        {
            SqlConnection connectForUpdate = new SqlConnection(conString);
            connectForUpdate.Open();

            string updateQuery = "update signUp set Email='" + txtEmail.Text + "',Password='" + txtPasswd.Text + "',FirstName='" +
                txtFName.Text + "',LastName='" + txtLName.Text + "' where Email='" + txtEmail.Text + "'";

            SqlCommand commandUpdate = new SqlCommand(updateQuery, connectForUpdate);
            commandUpdate.ExecuteNonQuery();
            Response.Redirect("Welcome.aspx?AccessType="+ accesstype);
        }
    }
}