﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BotDetect;
using BotDetect.Web;
using BotDetect.Web.UI;

namespace wilproject
{
    public partial class SignUp : System.Web.UI.Page
    {
        public string conString = "Data Source=DESKTOP-R720FQ7\\SQLEXPRESS;Initial Catalog=wilprojectDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            //  TextBox1.Text = DateTime.Today.ToShortDateString();
            // mm-dd-yyyy
            // and database yyyy-mm-dd
        }

        protected void SignUp_Click(object sender, EventArgs e)
        {
            SqlConnection connectForSignUp = new SqlConnection(conString);
            connectForSignUp.Open();
            bool correct = CaptchaBox.Validate(txtCaptcha.Text);
            txtCaptcha.Text = null;
            if (correct)
            {
                if (Page.IsValid)
                {
                    if (connectForSignUp.State == System.Data.ConnectionState.Open)
                    {
                        string signUpInsertDataQuery = "insert into signUp (Email,Password," +
                            "ConfirmPassword,FirstName,LastName," +
                            "DateOfBirth,AccessOfUser) values('" +
                            txtEmail.Text.ToString() + "','" +
                            txtPasswd.Text.ToString() + "','" +
                            txtCPasswd.Text.ToString() + "','" +
                            txtFName.Text.ToString() + "','" +
                            txtLName.Text.ToString() + "','" +
                            Request.Form["DateofBirth"].ToString() +
                            // txtDOB.Text.ToString() + 
                            "','RegularAcessUser')";
                        SqlCommand commandSignUp = new SqlCommand(signUpInsertDataQuery, connectForSignUp);
                        commandSignUp.ExecuteNonQuery();
                        Response.Redirect("Login.aspx");
                        // Response.Write("SignUp record inserted Successfully");
                    }
                }
            }
            else
            {
                Response.Write("Invalid captcha");
            }
        }

        //protected void DateChange(object sender, EventArgs e)
        //{
        //    txtDOB.Text = Calendar1.SelectedDate.ToShortDateString();
        //}
    }
}