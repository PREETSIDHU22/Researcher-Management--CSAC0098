﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace wilproject
{
    public partial class AddUser : System.Web.UI.Page
    {
        public string conString = "Data Source=DESKTOP-R720FQ7\\SQLEXPRESS;Initial Catalog=wilprojectDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void AddUser_Click(object sender, EventArgs e)
        {
            SqlConnection connectForAddUser = new SqlConnection(conString);
            connectForAddUser.Open();
            string addUserInsertDataQuery = "insert into signUp (Email,Password,ConfirmPassword,FirstName,LastName," +
                "DateOfBirth,AccessOfUser,PhoneNumber,Department,AddressLine1,AddressLine2,UserId) values('" +
                           txtEmail.Text.ToString() + "','" +
                           txtPasswd.Text.ToString() + "','" +
                            txtPasswd.Text.ToString() + "','" +
                           txtFName.Text.ToString() + "','" +
                           txtLName.Text.ToString() + "','" +
                           Request.Form["DateofBirth"].ToString() +
                           "','" + DropDownList1.SelectedItem.Value + "','" +
                           txtPhoneNumber.Text.ToString() + "','" +
                           DropDownList2.SelectedItem.Value + "','" +
                           txtAddressLine1.Text.ToString() + "','" +
                           txtAddressLine2.Text.ToString() + "','" + Request.QueryString["UserId"] + "')";


            SqlCommand commandUpdate = new SqlCommand(addUserInsertDataQuery, connectForAddUser);
            commandUpdate.ExecuteNonQuery();
            Type cstype = this.GetType();

            // Get a ClientScriptManager reference from the Page class.
            ClientScriptManager cs = Page.ClientScript;

            // Check to see if the startup script is already registered.
            if (!cs.IsStartupScriptRegistered(cstype, "PopupScript"))
            {
                String cstext = "alert('User Added Successfully');";
                cs.RegisterStartupScript(cstype, "PopupScript", cstext, true);
            }
            Response.Redirect("Welcome.aspx?AccessType=" + DropDownList1.SelectedItem.Value);
        }
    }
}