﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace wilproject
{
    public partial class Welcome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label1.Text = Request.QueryString["AccessType"];
        }

        protected void UserId_Click(object sender, EventArgs e)
        {

            Response.Redirect("EditUser.aspx?UserId=" + DropDownList2.SelectedItem.Value);

        }

        protected void btnAddUser_Click(object sender, EventArgs e)
        {
            int countItems = DropDownList2.Items.Count + 1;
            string userId = "U0" + countItems;
            Response.Redirect("AddUser.aspx?UserId=" + userId);
        }
    }
}