﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace wilproject
{
    public partial class EditUser : System.Web.UI.Page
    {
        public string conString = "Data Source=DESKTOP-R720FQ7\\SQLEXPRESS;Initial Catalog=wilprojectDB;Integrated Security=True";
        public string accesstype = "";
        public string userIdReq = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection connectForEdit = new SqlConnection(conString);
            connectForEdit.Open();
            string query = "";

            // string test = Request.QueryString["UserId"];
            if ((Request.QueryString["UserId"] != "") && (Request.QueryString["UserId"] != null))
            {
                query = "Select * from signUp" +
                              " where UserId='" + Request.QueryString["UserId"] + "'";
            }
            else
            {
                query = "Select * from signUp" +
              " where UserId='" + Session["UserId"] + "'";
            }

            SqlCommand cmd = new SqlCommand(query, connectForEdit);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                userIdReq = sdr.GetString(11);
                txtEmail.Text = sdr.GetString(0);
                txtPasswd.Attributes["value"] = sdr.GetString(1);
                txtFName.Text = sdr.GetString(3);
                txtLName.Text = sdr.GetString(4);
                if (sdr.GetString(7) != null)
                    txtPhoneNumber.Text = sdr.GetString(7);
                if (sdr.GetString(9) != null)
                    txtAddressLine1.Text = sdr.GetString(9);
                if (sdr.GetString(10) != null)
                    txtAddressLine2.Text = sdr.GetString(10);
                DropDownList1.SelectedItem.Value = sdr.GetString(6);
                DropDownList1.SelectedItem.Text = sdr.GetString(6);
                if (DropDownList1.SelectedItem.Value == "RegularAccessUser")
                {
                    DropDownList1.Items.Add("ElevatedAccessUser");
                    DropDownList1.Items.Add("Administrator");
                }
                else if (DropDownList1.SelectedItem.Value == "ElevatedAccessUser")
                {
                    DropDownList1.Items.Add("Administrator");
                    DropDownList1.Items.Add("RegularAccessUser");
                }
                else if (DropDownList1.SelectedItem.Value == "Administrator")
                {
                    DropDownList1.Items.Add("RegularAccessUser");
                    DropDownList1.Items.Add("ElevatedAccessUser");
                }
            }
            else
            {
                // Record not found
            }
            connectForEdit.Close();


        }

        protected void Update_Click(object sender, EventArgs e)
        {
            SqlConnection connectForUpdate = new SqlConnection(conString);
            connectForUpdate.Open();

            string updateQuery = "update signUp set Email='" + txtEmail.Text + "',Password='" + txtPasswd.Text + "',FirstName='" +
                txtFName.Text + "',LastName='" + txtLName.Text + "',AccessOfUser='" + DropDownList1.SelectedItem.Value + "',PhoneNumber='" + txtPhoneNumber.Text +
                "',Department='" + DropDownList2.SelectedItem.Value + "',AddressLine1='" + txtAddressLine1.Text + "',AddressLine2='" + txtAddressLine2.Text +
                "',DateOfBirth='" + Request.Form["DateofBirth"].ToString() + "' where Email='" + txtEmail.Text + "'";

            SqlCommand commandUpdate = new SqlCommand(updateQuery, connectForUpdate);
            commandUpdate.ExecuteNonQuery();
            Type cstype = this.GetType();

            // Get a ClientScriptManager reference from the Page class.
            ClientScriptManager cs = Page.ClientScript;

            // Check to see if the startup script is already registered.
            if (!cs.IsStartupScriptRegistered(cstype, "PopupScript"))
            {
                String cstext = "alert('Updated Successfully');";
                cs.RegisterStartupScript(cstype, "PopupScript", cstext, true);
            }
        }

        protected void btnRequest_Click(object sender, EventArgs e)
        {
            SqlConnection connectForCreateRequest = new SqlConnection(conString);
            connectForCreateRequest.Open();
            if (connectForCreateRequest.State == System.Data.ConnectionState.Open)
            {
                string RequestId = "R" + userIdReq;
                string RequestStatus = "pending";
                string createReqDataQuery = "insert into requests (RequestId,FirstName," +
                    "LastName,Department," +
                    "RequestStatus) values('" +
                    RequestId + "','" +
                            txtLName.Text.ToString() + "','" +
                             txtFName.Text.ToString() + "','" +
                             DropDownList2.SelectedItem.Value + "','" +
                           RequestStatus + "')";

                SqlCommand commandCreateRequest = new SqlCommand(createReqDataQuery, connectForCreateRequest);
                commandCreateRequest.ExecuteNonQuery();
                //   Response.Redirect("Login.aspx");
                Response.Write("Requested Successfully");
            }
        }
    }
}