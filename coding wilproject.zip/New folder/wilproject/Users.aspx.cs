﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace wilproject
{
    public partial class Users : System.Web.UI.Page
    {
        public string conString = "Data Source=DESKTOP-R720FQ7\\SQLEXPRESS;Initial Catalog=wilprojectDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            GridView2.Visible = false;
        }

        protected void searchButton_Click(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            string query = "SELECT UserId,FirstName,LastName,AccessOfUser,Department FROM [signUp] where UserId='" + searchBox.Text +
                "' OR FirstName='" + searchBox.Text +
                "' OR LastName='" + searchBox.Text +
                "' OR AccessOfUser='" + searchBox.Text +
                "' OR Department='" + searchBox.Text + "'";
            SqlConnection connectForSearch = new SqlConnection(conString);
            connectForSearch.Open();

            SqlCommand cmd = new SqlCommand(query, connectForSearch);
            SqlDataReader dr = cmd.ExecuteReader();
            GridView2.DataSource = dr;
            GridView2.DataBind();
            connectForSearch.Close();
            GridView2.Visible = true;
        }

        protected void resetSearchButton_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;
            GridView2.Visible = false;
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            string query = "SELECT UserId,FirstName,LastName,AccessOfUser,Department FROM [signUp] where Department='" +
                DropDownList2.SelectedItem.Value + "'";
            SqlConnection connectForSearch = new SqlConnection(conString);
            connectForSearch.Open();

            SqlCommand cmd = new SqlCommand(query, connectForSearch);
            SqlDataReader dr = cmd.ExecuteReader();
            GridView2.DataSource = dr;
            GridView2.DataBind();
            connectForSearch.Close();
            GridView2.Visible = true;
        }
    }
}