﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace wilproject
{
    public partial class Login : System.Web.UI.Page
    {
        public string conString = "Data Source=DESKTOP-R720FQ7\\SQLEXPRESS;Initial Catalog=wilprojectDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login_Click(object sender, EventArgs e)
        {
            SqlConnection connectForLogin = new SqlConnection(conString);
            connectForLogin.Open();
            string query = "Select * from signUp" +
               " where Email='" + txtEmail.Text + "' AND Password='" + txtPasswd.Text + "'";
            SqlCommand cmd = new SqlCommand(query, connectForLogin);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                // Label3.Text = sdr.GetString(6); 
                Session["UserId"] = sdr.GetString(11);
                Response.Redirect("Welcome.aspx?AccessType=" + sdr.GetString(6));
            }
            else
            {
                Label3.Text = "UserId & Password Is not correct Try again..!!";
            }
            connectForLogin.Close();
        }

        protected void SignUp_Click(object sender, EventArgs e)
        {
            Response.Redirect("SignUp.aspx");
        }
    }
}